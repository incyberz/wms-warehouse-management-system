<style type="text/css">
#blok_steps{
  width: 100%;
  display: grid;
  grid-template-columns: 25% 25% 25% 25%;
}

#blok_steps div{
  /*border: solid 1px red;*/
  text-align: center;
  font-size: 20px;
  /*margin-bottom: 20px;*/
}

.jumlah_podo{
  font-family: verdana;
  font-size: 25px;
  color: #555;
}

.jumlah_item_podo{
  color: #888;
  font-size: 14px;
}
.satuan_podo{
  color: #aaa;
  font-size: 12px;
}
</style>
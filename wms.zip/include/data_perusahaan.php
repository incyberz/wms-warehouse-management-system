<?php
$nama_usaha = 'CV. BIENSI FESYENINDO';
$alamat_usaha = 'Jl. Cimincrang No. 2B Kota Bandung, Jawa Barat 40613 Indonesia';
$no_hp_kantor = '081-223-456-789';
$no_telp_kantor = '(022)-7802482';
$no_wa_kantor = '081-223-456-789';


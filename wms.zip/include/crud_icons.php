<?php
$img_edit = '<img class="zoom pointer" src="assets/img/icons/edit.png" alt="edit" height=20px>';
$img_delete = '<img class="zoom pointer" src="assets/img/icons/delete.png" alt="delete" height=20px>';
$img_add = '<img class="zoom pointer" src="assets/img/icons/add.png" alt="add" height=20px>';
$img_save = '<img class="zoom pointer" src="assets/img/icons/save.png" alt="close" height=20px>';
$img_close = '<img class="zoom pointer" src="assets/img/icons/close.png" alt="close" height=20px>';
$img_detail = '<img class="zoom pointer" src="assets/img/icons/detail.png" alt="close" height=20px>';
$img_unique = '<img class="zoom pointer" src="assets/img/icons/unique.png" alt="close" height=20px>';
$img_manage = '<img class="zoom pointer" src="assets/img/icons/manage.png" alt="close" height=20px>';

<?php
$img_edit = '<img class="zoom pointer" src="assets/img/icons/edit.png" alt="edit" height=20px>';
$img_delete = '<img class="zoom pointer" src="assets/img/icons/delete.png" alt="delete" height=20px>';
$img_add = '<img class="zoom pointer" src="assets/img/icons/add.png" alt="add" height=20px>';
$img_save = '<img class="zoom pointer" src="assets/img/icons/save.png" alt="save" height=20px>';
$img_close = '<img class="zoom pointer" src="assets/img/icons/close.png" alt="close" height=20px>';
$img_cancel = '<img class="zoom pointer" src="assets/img/icons/cancel.png" alt="cancel" height=20px>';
$img_detail = '<img class="zoom pointer" src="assets/img/icons/detail.png" alt="detail" height=20px>';
$img_unique = '<img class="zoom pointer" src="assets/img/icons/unique.png" alt="unique" height=20px>';
$img_manage = '<img class="zoom pointer" src="assets/img/icons/manage.png" alt="manage" height=20px>';
$img_login_as = '<img class="zoom pointer" src="assets/img/icons/login_as.png" alt="login_as" height=20px>';
$img_help = '<img class="zoom pointer" src="assets/img/icons/help.png" alt="help" height=20px>';
$img_check = '<img class="zoom pointer" src="assets/img/icons/check.png" alt="check" height=20px>';


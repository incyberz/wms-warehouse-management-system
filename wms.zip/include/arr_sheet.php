<?php
$arr_sheet = [
  // 'Database',
  // 'Req Stockan',
  // 'Report Harian',
  'Penerimaan',
  'Pengeluaran',
  'Stock',
  'Daftar PO',
  // 'QRCode',
];
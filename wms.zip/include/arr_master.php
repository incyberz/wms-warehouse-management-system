<?php
$arr_master = [
  'user',
  'supplier',
  'buyer',
  'barang',
  'kategori',
  'gudang'
];
<?php
include 'pages/penerimaan/cetak_label.php';
ALTER TABLE `tb_sj_subitem` DROP `jenis_bahan`;

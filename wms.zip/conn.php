<?php
$cn = mysqli_connect(
  'localhost',
  'root',
  '',
  'db_wms'
);


<?php
$bintang = '<span class="tebal red pointer" onclick="alert(\'Field ini wajib diisi.\')">*</span>';
$unique = '<span class="tebal blue pointer" onclick="alert(\'Field ini isinya harus unique.\')">*</span>';
$kode_caption = $p=='user' ? 'Username' : 'Kode';

if(isset($_POST['btn_update'])){
  $pairs = '';
  foreach ($_POST as $key => $value) {
    if($key=="id_$p" || $key=='btn_update') continue;
    $value = $value=='' ? 'NULL' : '\''.clean_sql(strtoupper($value)).'\'';
    $pairs .= "$key = $value, ";
  }

  $id = $_POST["id_$p"];
  $s = "UPDATE tb_$p SET $pairs WHERE id=$id ";
  $s = str_replace(',  WHERE', ' WHERE',$s); // hilangkan koma
  // echo $s;
  $link_back = "<hr><a href='?master&p=$p'>Kembali ke Master $p</a>";

  try {
    $q = mysqli_query($cn,$s) or throw new Exception(mysqli_error($cn));
    echo div_alert('success', "Update success. $link_back");
  } catch (Exception $e) {
    if(strpos("salt$e",'Duplicate entry')){
      echo div_alert('danger',"Input kode sudah ada di database. Silahkan memakai kode unik lainnya. $link_back");
    }else{
      echo div_alert('danger',"Tidak bisa menjalankan Query SQL.");
    }
  }

}else{

  # =========================================
  # DESCRIBE THIS TABLE
  # =========================================
  $s = "DESCRIBE tb_$p";
  $q = mysqli_query($cn,$s) or die(mysqli_error($cn));
  $colField = [];
  $colType = [];
  $colLength = [];
  $colNull = [];
  $colKey = [];
  $colDefault = [];
  while($d=mysqli_fetch_assoc($q)){
    array_push($colField, $d['Field']);
    array_push($colNull, $d['Null']);
    array_push($colKey, $d['Key']);
    array_push($colDefault, $d['Default']);
  
    if($d['Type']=='timestamp'){
      $Type = 'timestamp';
      $Length = 19;
    }else{
      $pos = strpos($d['Type'],'(');
      $pos2 = strpos($d['Type'],')');
      $len = strlen($d['Type']);
      $len_type = $len - ($len-$pos);
      $len_length = $len - ($len-$pos2) - $len_type - 1;
    
      $Type = substr($d['Type'],0,$len_type);
      $Length = intval(substr($d['Type'],$pos+1, $len_length));
    }
  
    array_push($colType, $Type);
    array_push($colLength, $Length);
    // echo "<h1>Length : $Length</h1>";
  }
  
  
  # =========================================
  # SELECT SINGLE MAIN DATA
  # =========================================
  $s = "SELECT 
  a.id as id_$p, 
  a.kode as kode_$p, 
  a.nama as nama_$p,
  a.* 
  FROM tb_$p a 
  WHERE status=1 
  ORDER BY a.kode 
  ";
  $q = mysqli_query($cn,$s) or die(mysqli_error($cn));
  
  $tr = '';
  $i = 0;
  while($d=mysqli_fetch_assoc($q)){
    $i++;
    $id_p = $d["id_$p"];
  
    # =========================================
    # GET PROPERTIES
    # =========================================
    $li_ket = '';
    $inputs = '';
    foreach ($colField as $key => $field) {
      if($field=='id'
      ||$field=='kode'
      ||$field=='nama'
      ||$field=='password'
      ||$field=='date_created'
      ||$field=='date_modified'
      ||$field=='status'
      ) continue;
      // echo "<h1>field : $field</h1>";
      $nama_kolom = ucwords(str_replace('_',' ',$field));
      $isi = $d[$field]=='' ? $unset : $d[$field];
      $li_ket .= "
      <li><span class='miring abu proper'>$nama_kolom:</span> $isi</li> 
      ";
      
  
      # =========================================
      # FIELD CAN BE NULL
      # =========================================
      $required = $colNull[$key]=='YES' ? '' : 'required';
      $stars = $colNull[$key]=='YES' ? '' : $bintang;
      
      # =========================================
      # KEY FIELD HANDLERS
      # =========================================
      $unik = $colKey[$key]=='UNI' ? $unique : '';
      $link_fkey = '';
      if($colKey[$key]=='MUL'){
        # =========================================
        # CREATE INPUT SELECT
        # =========================================
        $arr = explode('_', $colField[$key]);
        $link_fkey = "<a href='?master&p=$arr[1]' onclick='return confirm(\"Menuju manage $arr[1]?\")'>$img_manage</a>";
        $s2 = "SELECT id,nama FROM tb_$arr[1] WHERE status=1";
        $q2 = mysqli_query($cn,$s2) or die(mysqli_error($cn));
        $opt = '';
        while($d2=mysqli_fetch_assoc($q2)){
          $selected = $d2['id'] == $d[$colField[$key]] ? 'selected' : '';
          $opt .= "<option value='$d2[id]' $selected>$d2[nama]</option>";
        }
  
        $input = "<select class='form-control' name='$field'>$opt</select>";
        
      }else{
        # =========================================
        # NORMAL INPUT OR TEXTAREA
        # =========================================
        $param_max = '';
        $param_maxlength = '';
        $param_step = '';
    
        $ftype = $colType[$key];
        if($ftype=='varchar'||$ftype=='char'){
          $type = 'text';
          $param_maxlength = $ftype=='varchar' ? "maxlength='$colLength[$key]' " : "maxlength='$colLength[$key]' minlength='$colLength[$key]' ";
        }elseif($ftype=='int'||$ftype=='smallint'||$ftype=='tinyint'||$ftype=='decimal'){
          $type = 'number';
          if($ftype=='decimal') $param_step = 'step="0.01"';
    
        }elseif($ftype=='timestamp'){
          $type = 'date';
        }else{
          die(div_alert('danger',"Type of field: $ftype belum ditentukan."));
        }
        $params = "
          type='$type'
          class='form-control mb2' 
          name='$field' 
          value='$d[$field]' 
          placeholder='$nama_kolom' 
          $param_max 
          $param_maxlength 
          $param_step 
          $required
        ";
    
        if($colLength[$key]>100){
          $input = "<textarea $params>$d[$field]</textarea>";
        }else{
          $input = "<input $params>";
        }
    
        
      }
  
      # =========================================
      # FINAL OUTPUT OF INPUT | TEXTAREA | SELECT
      # =========================================
      $inputs .= "
      <div class='mb1 darkabu '>$nama_kolom $stars $unik $link_fkey</div>
      $input
      ";
    }
  
  
    $kode = $d["kode_$p"];
    $nama = $d["nama_$p"];
  
    $dual_id = $p."__$id_p";
    $toggle_id = 'edit_'.$p.'__toggle__'.$id_p;
    $delete_id = 'edit_'.$p.'__delete__'.$id_p.'__from_db';
    $close_id = 'edit_'.$p.'__close__'.$id_p;
    $cancel_id = 'edit_'.$p.'__cancel__'.$id_p;
    $tambah_id = $p.'__tambah';
  
    $is_new = strpos("salt$kode",'NEW');
    $hideit_blok_edit = $is_new ? '' : 'hideit';
    $gradasi_item = $is_new ? 'gradasi-kuning red bold' : '';
  
    $tr .= "
      <tr id=source_edit_$dual_id class='$gradasi_item'>
        <td width=30px>$i</td>
        <td width=150px>$kode</td>
        <td>
          $nama 
          <span class='btn_aksi' id='ket_detail__toggle__$id_p'>$img_detail</span>
          <div class='kecil ket hideit' id='ket_detail__$id_p'>
            <ul class='p0 pl3'>$li_ket</ul>
          </div>
        </td>
        <td width=70px>
          <span class='btn_aksi' id=$toggle_id>$img_edit</span> 
          <span class='btn_aksi' id=$delete_id>$img_delete</span>
        </td>
      </tr>
      <tr class=$hideit_blok_edit id=edit_$dual_id>
        <td colspan=4>
          <form method=post class=formulir>
            <input name=id_$p value=$id_p type=hidden>
            <div class='p2 br5 mb4 border-merah gradasi-kuning'>
              <div class='flex-between mb1'>
                <div class='tebal abu proper'>Edit Data $p</div>
                <div>
                  <span class='btn_aksi' id='$close_id'>$img_close</span>
                </div>
              </div>  
  
              <div class='mb1 proper'>$kode_caption $p $bintang $unique</div>
              <input name=kode class='form-control mb2' value='$kode' minlength=3 maxlength=20>
              <div class='mb1 proper'>Nama $p $bintang</div>
              <input name=nama class='form-control mb2' value='$nama' minlength=3 maxlength=50>
              
              $inputs
  
              <div class=' '>
                <button class='btn btn-success btn-sm' name=btn_update>Update</button>
                <span class='btn btn-danger btn-sm btn_aksi' id=$cancel_id>Cancel</span>
              </div>
            </div>
          </form>
  
        </td>
      </tr>
    ";
    if($is_new) break;
  }
  
  echo $tr=='' ? div_alert('danger', 'Belum ada data $p.') : "
    <div class='mb2 kanan'>
      <a class='btn btn-success btn-sm btn_aksi' id=$tambah_id>Tambah</a>
    </div>
    <table class='table table-hover'>
      <thead class=upper>
        <th>NO</th>
        <th>$kode_caption</th>
        <th>$p</th>
        <th>AKSI</th>
      </thead>
      $tr
    </table>
  ";
}
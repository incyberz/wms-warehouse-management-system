<div class="pagetitle">
  <h1>Shipping</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="?pengeluaran">Pengeluaran</a></li>
      <li class="breadcrumb-item"><a href="?pengeluaran&p=data_do">Data DO</a></li>
      <li class="breadcrumb-item"><a href="?pengeluaran&p=terima_do">Terima DO Baru</a></li>
      <li class="breadcrumb-item"><a href="?pengeluaran&p=packing">Packing</a></li>
      <li class="breadcrumb-item active">Shipping</li>
    </ol>
  </nav>
</div>

<?php
set_title('Shipping');
?>
<div class="alert alert-danger">Page ini masih dalam tahap pengembangan. Terimakasih.</div>
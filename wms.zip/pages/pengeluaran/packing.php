<div class="pagetitle">
  <h1>Packing</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="?pengeluaran">Pengeluaran</a></li>
      <li class="breadcrumb-item"><a href="?pengeluaran&p=data_do">Data DO</a></li>
      <li class="breadcrumb-item"><a href="?pengeluaran&p=terima_do">Terima DO Baru</a></li>
      <li class="breadcrumb-item active">Packing</li>
    </ol>
  </nav>
</div>

<?php
set_title('Packing');
?>
<div class="alert alert-danger">Page ini masih dalam tahap pengembangan. Terimakasih.</div>
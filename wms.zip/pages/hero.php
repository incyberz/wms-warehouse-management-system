<section id="hero">
  <div class="judul-hero">
    <h2>Welcome to LShop !</h2>
    <p>The Best Shopping Place on Earth!</p>
  </div>
  <div class="blok-img-hero">
    <img src="img/hero1.png" alt="hero" class="img-hero" />
  </div>
</section>
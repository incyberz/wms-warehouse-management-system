<style>
  .no-bullet{list-style: none}
</style>
<div class="pagetitle">
  <h1>Tambah PO</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="?po">PO Home</a></li>
      <li class="breadcrumb-item"><a href="?po&p=data_po">Data PO</a></li>
      <li class="breadcrumb-item active">Manage PO</li>
    </ol>
  </nav>
</div>
<?php
include 'include/arr_supplier.php';
# ==========================================
# SUPPLIER
# ==========================================
$opt = '';
foreach ($arr_supplier as $id => $nama) {
  $opt.= "<option value=$id>$nama</option>";
}
$select_supplier = "
  <select class='form-control' name=id_supplier>$opt</select>
";


$aksi = $_GET['aksi'] ?? '';
$no_po = $_GET['no_po'] ?? '';
if($no_po==''){
  if(isset($_POST['btn_buat_po'])){
    $kode = clean_sql($_POST['kode']);
    $id_supplier = clean_sql($_POST['id_supplier']);
    $s = "INSERT INTO tb_po (kode,id_supplier) VALUES ('$kode',$id_supplier)";
    $q = mysqli_query($cn,$s) or die(mysqli_error($cn));
    jsurl("?po&p=manage_po&no_po=$kode");
    exit;
  }

  $no_po = date('Ymd').'01-MTL';
  ?>
  <form method=post>
    <div class="wadah gradasi-hijau" style='max-width:500px;'>
      <h2 class='abu f20'>Create Purchase Order</h2>
      <hr>
      Nomor PO
      <input name=kode type="text" class="form-control mt1 mb2 consolas f30 upper" value="<?=$no_po?>">
      Supplier
      <div class="mt1 mb2">
        <?=$select_supplier?>
      </div>
      <button class='btn btn-primary w-100' name=btn_buat_po>Buat PO Baru</button>
    </div>
  </form>


  <?php
}else{
  include 'tambah_po.php';  
}
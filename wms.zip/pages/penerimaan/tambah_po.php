<?php
if(!isset($no_po)) die(erid('no_po'));


# ==========================================
# GET DATA PO
# ==========================================
$s = "SELECT 
a.id as id_po,
a.*,
b.id as id_supplier,
b.nama as nama_supplier ,
b.no_telfon as telp_supplier ,
b.alamat as alamat_supplier 

FROM tb_po a   
JOIN tb_supplier b ON a.id_supplier=b.id 
WHERE a.kode='$no_po' ";
$q = mysqli_query($cn,$s) or die(mysqli_error($cn));
if(mysqli_num_rows($q)==0){
  die(div_alert('danger',"Data PO tidak ditemukan. <hr>Silahkan cek pada <a href='?po&p=data_po'>List Data PO</a>"));
}

$d = mysqli_fetch_assoc($q);

$hideit = 'hideit';

//buyer
$nama_buyer = $nama_usaha;
$alamat_buyer = $alamat_usaha;
$telp_buyer = "$no_telp_kantor / $no_hp_kantor";
$wa_buyer = $no_wa_kantor;

//supplier
$id_supplier = $d['id_supplier'];
$nama_supplier = $d['nama_supplier'];
$telp_supplier = $d['telp_supplier'];
$alamat_supplier = $d['alamat_supplier'];

$id_po = $d['id_po'];
$tanggal_pemesanan = $d['tanggal_pemesanan'];
$tanggal_pengiriman = $d['tanggal_pengiriman'];
$durasi_bayar = $d['durasi_bayar'];
$perintah_po = $d['perintah_po'] ?? "Harap dikirim ke $nama_buyer barang-barang sesuai jumlah, spesifikasi dibawah ini, dengan ketentuan sebagaimana tertera dalam Purchase Order ini:";

$durasi_bayar_show = $durasi_bayar=='' ? $unset : "$durasi_bayar hr kontrabon";

# ==========================================
# SELECT SUPPLIER
# ==========================================
$opt = '';
$ket_supplier = '';
$s = "SELECT * FROM tb_supplier";
$q = mysqli_query($cn,$s) or die(mysqli_error($cn));
while($d=mysqli_fetch_assoc($q)){
  $alamat = $d['alamat']=='' ? "Alamat: $unset" : "Alamat: $d[alamat]";
  $no_telfon = $d['no_telfon']=='' ? "Telfon: $unset" : "Telp. $d[no_telfon]";
  $no_hp = $d['no_hp']=='' ? '' : ", HP. $d[no_hp]";
  $no_wa = $d['no_wa']=='' ? '' : ", WA. $d[no_wa]";
  $no_fax = $d['no_fax']=='' ? '' : ", Fax. $d[no_fax]";

  $hideit = $id_supplier==$d['id'] ? '' : 'hideit';
  $ket_supplier .= "
  <div class='ket_supplier $hideit' id=ket_supplier__$d[id]>
    $alamat $no_telfon $no_hp $no_wa $no_fax 
  </div>
  ";

  $selected = $id_supplier==$d['id'] ? 'selected' : '';
  $opt.= "<option value='$d[id]' $selected>$d[nama]</option>";
}

$hideit = 'hideit'; //for items


$select_supplier = "<select class='form-control' name=id_supplier>$opt</select>";

# ==========================================
# KET PO
# ==========================================
$ket_po = 'Lorem ipsum dolor sit amet consectetur, adipisicing elit___Distinctio doloribus corporis ducimus, veniam officiis expedita quidem voluptates sed, magni veritatis odio officia___Praesentium ipsum iusto tenetur facilis odio accusamus temporibus';

$arr_ket_po = explode('___',$ket_po);
$li = '';
foreach ($arr_ket_po as $key => $item_ket_po) {
  $id_toggle = "edit_ket_po__toggle__$key";
  $id_save = "edit_ket_po__save__$key";
  $id_close = "edit_ket_po__close__$key";
  $id_delete = "edit_ket_po__delete__$key";
  $li.="
    <li class=mb2  id=source_edit_ket_po__$key>
      $item_ket_po 
      <span class='btn_aksi' id=$id_toggle>$img_edit</span>
      <span class='btn_aksi' id=$id_delete>$img_delete</span>
    </li>
    <li class='no-bullet $hideit' id=edit_ket_po__$key>
      <div class='border-merah gradasi-kuning br5 p2 flex-between mb4'>
        <textarea class='form-control'>$item_ket_po</textarea>
        <div class='ml2' style='width: 60px'>
          <span class='btn_aksi' id=$id_save>$img_save</span>
          <span class='btn_aksi' id=$id_close>$img_close</span>
        </div>
      </div>
    </li>  
  ";
}

$ket_po_show = "
  <ul>
    $li
  </ul>
";

# ==========================================
# KET ITEM PO
# ==========================================
$ket_item_po = 'Lorem ipsum dolor sit amet consectetur, adipisicing elit___Distinctio doloribus corporis ducimus, veniam officiis expedita quidem voluptates sed, magni veritatis odio officia___Praesentium ipsum iusto tenetur facilis odio accusamus temporibus';

$arr_ket_item_po = explode('___',$ket_item_po);
$li = '';
foreach ($arr_ket_item_po as $key => $item_ket_item_po) {
  $id_toggle = "edit_ket_item_po__toggle__$key";
  $id_save = "edit_ket_item_po__save__$key";
  $id_close = "edit_ket_item_po__close__$key";
  $id_delete = "edit_ket_item_po__delete__$key";
  $li.="
    <li class=mb2  id=source_edit_ket_item_po__$key>
      $item_ket_item_po 
      <span class='btn_aksi' id=$id_toggle>$img_edit</span>
      <span class='btn_aksi' id=$id_delete>$img_delete</span>
    </li>
    <li class='no-bullet $hideit' id=edit_ket_item_po__$key>
      <div class='border-merah gradasi-kuning br5 p2 flex-between mb4'>
        <textarea class='form-control'>$item_ket_item_po</textarea>
        <div class='ml2' style='width: 60px'>
          <span class='btn_aksi' id=$id_save>$img_save</span>
          <span class='btn_aksi' id=$id_close>$img_close</span>
        </div>
      </div>
    </li>  
  ";
}

$ket_item_po_show = "
  <ul>
    $li
  </ul>
";

$hideit = 'hideit'; // for header





























?>



<div class="bordered p2 bg-white">

  <div class="mb1">
    <div class="row">
      <div class="col-4">
        <div class="bordered p1 h-100">
          <div class="tebal"><?=$nama_buyer?></div>
          <div class="kecil">
            <?=$alamat_buyer?> 
            Telp. <?=$telp_buyer?>
            WA. <?=$wa_buyer?>
          </div>
        </div>
      </div>
      <div class="col-4 tengah f30">
        <div class="bordered p1 h-100" style="margin: 0 -25px">
          Purchase Order
          <hr style='margin: 5px 0'>
          <span id="no_po"><?=$no_po?></span>
        </div>
      </div>
      <div class="col-4">
        <div class="bordered p1 h-100">
          <div class='flex-between'>
            <div>Kepada Yth.</div>
            <div><span class='btn_aksi' id="edit_judul_po__toggle"><?=$img_edit?></span></div>
          </div>
          <div class="tebal "><?=$nama_supplier?></div> 
          <div><?=$alamat_supplier?></div>
          <div><?=$telp_supplier?></div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="tengah">
    <div class="row">
      <div class="col-7 " style="padding-right: 0">
        <div class="bordered p1 h-100 ">
          <div class="row">
            <div class="col-4">
              <div>No. Supplier</div>
              <div>SUP001</div>
            </div>
            <div class="col-4">
              <div class=" h-100 " style="border-left: solid 1px #ccc; border-right: solid 1px #ccc">
                <div>Kontak Personal</div>
                <div>CV. Kurnia Jaya Perkasa</div>
              </div>
            </div>
            <div class="col-4">
              <div>Tanggal Pemesanan</div>
              <div>05 - 09 - 2023</div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-5 " style="padding-left:0">
        <div class="bordered p1 h-100">
          <div class="row">
            <div class="col-6">
              <div>Tanggal Pengiriman</div>
              <div>09 - 10 - 2023</div>
            </div>
            <div class="col-6">
              <div class="h-100" style="border-left: solid 1px #ccc">
                <div>Jangka Waktu Pembayaran</div>
                <div><?=$durasi_bayar_show?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="">
    <div class="row">
      <div class="col-7 " style="padding-right: 0">
        <div class="bordered p1 h-100 ">
          <div class="row">
            <div class="col-4">
              <div>Tempat Pengiriman:</div>
            </div>
            <div class="col-8">
              <div class=" h-100 p1" style="border: none">
                <div><?=$alamat_buyer?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-5 " style="padding-left:0">
        <div class="bordered p1 h-100">
          <div class="row">
            <div class="col-5">
              <div>Tempat Penagihan:</div>
            </div>
            <div class="col-7">
              <div class="h-100">
                <div><?=$alamat_buyer?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>























  <!-- ================================================================ -->
  <!-- EDIT JUDUL PO -->
  <!-- ================================================================ -->
  <div class="gradasi-kuning border-merah br5 mt2 mb2 p2 <?=$hideit?>" id=edit_judul_po>
    <div class="row">
      <div class="col-1">&nbsp;</div>
      <div class="col-10">
        <h2 class='tengah darkblue f20'>Edit Judul PO</h2>
      </div>
      <div class="col-1 kanan">
        <span class="btn_aksi" id="edit_judul_po__close"><?=$img_close?></span>
      </div>
    </div>
    <div class="wadah kecil flex-between bg-white">
      <div>
        <b>Identitas Perusahaan</b>
        <div class=""><span class="abu miring">Perusahaan :</span> <?=$nama_usaha?></div>
        <div class=""><span class="abu miring">Alamat Usaha :</span> <?=$alamat_usaha?></div>
        <div class=""><span class="abu miring">Telepon Kantor :</span> <?=$no_telp_kantor?></div>
        <div class=""><span class="abu miring">Whatsapp Kantor :</span> <?=$no_wa_kantor?></div>

      </div>
      <div>
        <a href="?identitas_perusahaan" onclick='return confirm("Menuju laman Edit Perusahaan?")'><?=$img_edit?></a>
      </div>
    </div>

    Nomor PO:
    <input class="form-control mb2" value='<?=$no_po?>'>

    <div class="wadah ">
      Buyer:
      <input class="form-control mb2" value='<?=$nama_buyer?>'>

      Alamat Buyer:
      <input class="form-control mb2" value='<?=$alamat_buyer?>'>

      Telfon/HP Buyer:
      <input class="form-control mb2" value='<?=$telp_buyer?>'>
    </div>

    <div class="wadah ">
      Pilih Supplier:
      <?=$select_supplier?>

      <div class="p1 flex-between kecil">
        <div><?=$ket_supplier?></div>
        <div>
          <a href="?master&p=supplier" onclick='return confirm("Edit Data Supplier ini?")'><?=$img_edit?></a>
        </div>
      </div>

    </div>


    Tanggal Pemesanan:
    <input type='date' class="form-control mb2" value='<?=$tanggal_pemesanan?>'>

    Tanggal Pengiriman:
    <input type='date' class="form-control mb2" value='<?=$tanggal_pengiriman?>'>

    Jangka Waktu Pembayaran:
    <input class="form-control mb2" value='<?=$durasi_bayar?>'>

    Tempat Pengiriman:
    <input class="form-control mb2" value='<?=$alamat_buyer?>'>

    Tempat Penagihan:
    <input class="form-control mb2" value='<?=$alamat_buyer?>'>

    <div class="flex-between mt-4">
      <button class="btn btn-primary btn_aksi" id=edit_judul_po__simpan>Simpan</button> 
      <button class="btn btn-danger btn_aksi" id=edit_judul_po__cancel>Cancel</button> 
    </div>
  </div>
  <!-- END // EDIT JUDUL PO -->
  




















  <!-- ================================================================ -->
  <!-- PERINTAH PO DAN KETERANGANS -->
  <!-- ================================================================ -->
  <div class='bordered mt1 p1'>
    <?=$perintah_po?> 
    <span class="btn_aksi" id="edit_perintah_po__toggle"><?=$img_edit?></span>
  </div>
  <!-- ================================================================ -->
  <!-- EDIT PERINTAH PO -->
  <!-- ================================================================ -->
  <div class="gradasi-kuning border-merah br5 mt2 mb2 p2 <?=$hideit?>" id=edit_perintah_po>
    <div class="row">
      <div class="col-1">&nbsp;</div>
      <div class="col-10">
        <h2 class='tengah darkblue f20'>Edit Perintah PO</h2>
      </div>
      <div class="col-1 kanan">
        <span class="btn_aksi" id="edit_perintah_po__close"><?=$img_close?></span>
      </div>
    </div>

    Perintah PO:
    <textarea rows="10" class="form-control mb2"><?=$perintah_po?></textarea>

    <div class="flex-between mt-4">
      <button class="btn btn-primary btn_aksi" id=edit_perintah_po__simpan>Simpan</button> 
      <button class="btn btn-danger btn_aksi" id=edit_perintah_po__cancel>Cancel</button> 
    </div>
  </div>
  <!-- END // EDIT PERINTAH PO -->

  


  <div class='bordered mt1 p1 mb4'>
    <div style='display:grid; grid-template-columns: 50px auto'>
      <div>Ket:</div>
      <div>
        <?=$ket_po_show?>
        <div class='mb1 pl4 ml2'>
          <span class="btn_aksi" id="add_ket_po__add"><?=$img_add?></span>
        </div>
      </div>
  
    </div>
  </div>
  
  <table class="table table-striped">
    <thead class=gradasi-hijau>
      <th>NO</th>
      <th>ITEM</th>
      <th>KETERANGAN ITEM</th>
      <th>SATUAN</th>
      <th>QUANTITY</th>
      <th>HARGA</th>
      <th>JUMLAH</th>
    </thead>
    
    <tr id=source_edit_item_po__1>
      <td>1</td>
      <td>K001</td>
      <td>
        KAIN KATUN JET BLACK 
        <span class="btn_aksi" id="edit_item_po__delete__1"><?=$img_delete?></span>
      </td>
      <td>KG</td>
      <td class=kanan>503.00</td>
      <td class=kanan>115.315.32</td>
      <td class=kanan>58.033.876.21</td>
    </tr>
    <tr id=source_edit_item_po__2>
      <td>2</td>
      <td>K027</td>
      <td>
        KAIN BATIK ORI CIREBON MEGA MENDUNG 
        <span class="btn_aksi" id="edit_item_po__delete__2"><?=$img_delete?></span>
      </td>
      <td>KG</td>
      <td class=kanan>19.00</td>
      <td class=kanan>116.315.32</td>
      <td class=kanan>2.208.108.21</td>
    </tr> 
    <tr>
      <td><span class='miring abu kecil'>3</span></td>
      <td colspan=6 >
        <span class="green pointer">
          Tambah item 
          <span class="btn_aksi" id="add_item_po__add"><?=$img_add?></span>
        </span>
      </td>
    </tr> 
    <tfoot class=gradasi-kuning>
      <tr>
        <td colspan=4 class=kanan>Total</td>
        <td class=kanan>522,00</td>
        <td>&nbsp;</td>
        <td class=kanan>60.211.711,11</td>
      </tr>
      <tr>
        <td colspan=4 class=kanan>PPN 11%</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td class=kanan>6.623.711,11</td>
      </tr>
      <tr>
        <td colspan=4 class=kanan>Total + PPN</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td class=kanan>66.835.711,11</td>
      </tr>
    </tfoot>
  
  </table>
  
  <div class=' mt1 p1'>
    <div style='display:grid; grid-template-columns: 70px auto'>
      <div class=tebal>Catatan:</div>
      <div>
        <?=$ket_item_po_show?>
        <div class='mb1 pl4 ml2'><?=$img_add?></div>
      </div>
    </div>
  </div>
  
  <div class="bordered p1 tengah">
    Diverifikasi oleh:
  </div>
  <div class="tengah">
    <div class="row">
      <div class="col-7 " style="padding-right: 0">
        <div class="bordered p1 h-100 ">
          <div class="row">
            <div class="col-4">
              <div class='abu kecil'>Adm PO</div>
              <div>Ajat Sudrajat</div>
              <div class='miring green kecil'>at Sun, Dec 11, 2023 12:32:54</div>
            </div>
            <div class="col-4">
              <div class=" h-100 " style="border-left: solid 1px #ccc; border-right: solid 1px #ccc">
              <div class='abu kecil'>Departemen</div>
              <div>Suhendar</div>
              <div class='miring green kecil'>at Mon, Dec 12, 2023 08:32:54</div>
              </div>
            </div>
            <div class="col-4">
              <div class='abu kecil'>Departemen</div>
              <div>Ujang Aries</div>
              <div class='miring green kecil'>at Mon, Dec 12, 2023 09:30:34</div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-5 " style="padding-left:0">
        <div class="bordered p1 h-100">
          <div class="row">
            <div class="col-6 darkred">
              <div class='abu kecil'>Direktur</div>
              <div>Sulaiman Arifin</div>
              <div class='miring kecil'>Unverified</div>
            </div>
            <div class="col-6">
              <div class="h-100" style="border-left: solid 1px #ccc">
                <div class='abu kecil'>Supplier</div>
                <div>Syarif Amir</div>
                <div class='miring green kecil'>at Fri, Dec 6, 2023 09:23:02</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="alert alert-info mt-2">Perhatian! Jika PO sudah disahkan (diverifikasi) maka PO dan item-itemnya tidak dapat lagi diubah.</div>

<div>
  <button class="btn btn-primary">Cetak PO</button>
  <button class="btn btn-danger">Hapus</button>
</div>



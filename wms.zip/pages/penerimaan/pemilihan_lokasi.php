<div class="pagetitle">
  <h1>Pemilihan Lokasi Info</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="?penerimaan">Penerimaan</a></li>
      <li class="breadcrumb-item active">Pemilihan Lokasi Info</li>
    </ol>
  </nav>
</div>

<p>Untuk Pemilihan Lokasi (Rak) untuk barang dapat dilakukan pada saat Manage Subitems. Silahkan menuju tahapan sebelumnya terlebih dahulu!</p>

<div class="alert alert-info">
  Tahapan sebelumnya: 
  <ol>
    <li><a href="?penerimaan&p=terima_sj_baru"><?=$img_prev?> Pencarian atau Penerimaan Surat Jalan Baru</a></li>
    <li>Manage Surat Jalan (Pengisian Item QTY sesuai PO)</li>
    <li>Pengisian Item QTY Diterima dan Cetak BBM</li>
    <li>Manage Subitems | Cetak Label | Pemilihan Lokasi</li>
  </ol>
</div>
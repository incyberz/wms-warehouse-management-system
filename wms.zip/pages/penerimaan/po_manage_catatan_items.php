<div class=' mt1 p1'>
  <div style='display:grid; grid-template-columns: 70px auto'>
    <div class=tebal>Catatan:</div>
    <div>
      <?=$ket_item_po_show?>
      <div class='mb1 pl4 ml2'><?=$img_add?></div>
    </div>
  </div>
</div>

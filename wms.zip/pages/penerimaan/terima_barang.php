<div class="pagetitle">
  <h1>Terima Barang</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="?po">PO Home</a></li>
      <li class="breadcrumb-item active">Terima Barang</li>
    </ol>
  </nav>
</div>

<p>Page terima barang digunakan untuk verifikasi isi PO saat barang sudah datang ke Gudang.</p>

<div class="alert alert-danger">Page ini masih dalam tahap pengembangan. Terimakasih.</div>
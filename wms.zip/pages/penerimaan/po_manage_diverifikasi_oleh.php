<div class="bordered p1">
  Statu PO: <span class="miring darkred">belum diverifikasi</span>
</div>
<!-- <div class="bordered p1 tengah">
  Diverifikasi oleh:
</div>
<div class="tengah">
  <div class="row">
    <div class="col-7 " style="padding-right: 0">
      <div class="bordered p1 h-100 ">
        <div class="row">
          <div class="col-4">
            <div class='abu kecil'>Adm PO</div>
            <div>Ajat Sudrajat</div>
            <div class='miring green kecil'>at Sun, Dec 11, 2023 12:32:54</div>
          </div>
          <div class="col-4">
            <div class=" h-100 " style="border-left: solid 1px #ccc; border-right: solid 1px #ccc">
            <div class='abu kecil'>Departemen</div>
            <div>Suhendar</div>
            <div class='miring green kecil'>at Mon, Dec 12, 2023 08:32:54</div>
            </div>
          </div>
          <div class="col-4">
            <div class='abu kecil'>Departemen</div>
            <div>Ujang Aries</div>
            <div class='miring green kecil'>at Mon, Dec 12, 2023 09:30:34</div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-5 " style="padding-left:0">
      <div class="bordered p1 h-100">
        <div class="row">
          <div class="col-6 darkred">
            <div class='abu kecil'>Direktur</div>
            <div>Sulaiman Arifin</div>
            <div class='miring kecil'>Unverified</div>
          </div>
          <div class="col-6">
            <div class="h-100" style="border-left: solid 1px #ccc">
              <div class='abu kecil'>Supplier</div>
              <div>Syarif Amir</div>
              <div class='miring green kecil'>at Fri, Dec 6, 2023 09:23:02</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> -->
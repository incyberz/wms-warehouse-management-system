<div class="pagetitle">
  <h1>Stok Gudang</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="?po">PO Home</a></li>
      <li class="breadcrumb-item active">Stok Gudang</li>
    </ol>
  </nav>
</div>

<p>Page ini digunakan untuk:</p>
<ul>
  <li>Melihat Stok Gudang awal</li>
  <li>Penempatan barang pada Lot/Rak/Gudang yang sesuai</li>
  <li>Melihat Stok Gudang akhir</li>
</ul>

<div class="alert alert-danger">Page ini masih dalam tahap pengembangan. Terimakasih.</div>
<div class="pagetitle">
  <h1>Penempatan</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="?po">PO Home</a></li>
      <li class="breadcrumb-item active">Penempatan</li>
    </ol>
  </nav>
</div>

<p>Page penempatan barang digunakan untuk:</p>
<ul>
  <li>Barcode System</li>
  <li>Klasifikasi Barang</li>
</ul>

<div class="alert alert-danger">Page ini masih dalam tahap pengembangan. Terimakasih.</div>